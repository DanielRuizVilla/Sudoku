/*-----------------------------------------PROBLEMA DEL SUDOKU-----------------------------------------*/

// ----------------------------------------------------------------------------
// Daniel Ruiz Villa. 77757166P - Grupo 3 - Luis Daniel Hernandez Molinero	  |
// Grado en Ingenieria Informatica. 3er Curso. Sistemas Inteligentes.         |
// ----------------------------------------------------------------------------

#include <ga/GASimpleGA.h> // Algoritmo Genetico Simple
#include <ga/GA1DArrayGenome.h> //Genoma = array de enteros (dim. 1), alelos
#include <iostream>
#include <string>
#include <fstream>
#include <math.h>
#include <list>
using namespace std;

float Objective(GAGenome &); //Fitness/objetivo.
GABoolean Termina(GAGeneticAlgorithm &);
int number;

struct plantilla{
       int tam;
       int *fijo;
};

void leerSudoku(struct plantilla *S,char *nombreF){
   ifstream f(nombreF);

   f>>S->tam;
   number=S->tam;

   S->fijo = new int[S->tam*S->tam];

   for(int i=0;i<S->tam*S->tam;i++)
           f>>S->fijo[i];

   f.close();
}

void InicioSudoku(GAGenome& g){

     //*******************************************************//
     //*******************************************************//
     // Hacer el casting correspondiente para obtener genome  //
     //*******************************************************//
     //*******************************************************//
     GA1DArrayAlleleGenome<int> & genome =(GA1DArrayAlleleGenome<int> &) g;

     struct plantilla * plantilla1;
     plantilla1 = (struct plantilla *) genome.userData();

     int aux[plantilla1->tam];

     for(int f=0;f<plantilla1->tam;f++){

          for(int j=0;j<plantilla1->tam;j++) aux[j]=0;

          for(int j=1;j<=plantilla1->tam;j++){
            int v=GARandomInt(0,plantilla1->tam-1);
            while (aux[v]!=0) v=(v+1)%plantilla1->tam;
            aux[v]=j;
          }

          int i=0;

          while(i<plantilla1->tam){

              while((plantilla1->fijo[(f*plantilla1->tam)+i]==0) && (i<plantilla1->tam)) i++;

              if (i<plantilla1->tam){

                     bool encontrado=false;
                     for(int j=0;(j<plantilla1->tam) && (!encontrado);j++)
                             if (aux[j]==plantilla1->fijo[(f*plantilla1->tam)+i]) {
                                encontrado=true;
                                aux[j]=aux[i];
                             }

                     aux[i]=plantilla1->fijo[(f*plantilla1->tam)+i];
              }
              i++;

          }

          for(int c=0;c<plantilla1->tam;c++)
                  genome.gene((f*plantilla1->tam)+c,aux[c]);
     }
}

int CruceSudoku(const GAGenome& p1,const GAGenome & p2,GAGenome* c1,GAGenome* c2){

     //******************************************************//
     //******************************************************//
     // Hacer el casting correspondiente para obtener m y p  //
     //******************************************************//
     //******************************************************//
    GA1DArrayAlleleGenome<int> &m =(GA1DArrayAlleleGenome<int> &) p1;
    GA1DArrayAlleleGenome<int> &p =(GA1DArrayAlleleGenome<int> &) p2;
    struct plantilla * plantilla1 = (struct plantilla *) m.userData();
    int n=0;

    int punto1=GARandomInt(0,m.length());
    while ((punto1%plantilla1->tam)!=0) punto1++;
    int punto2=m.length()-punto1;

    if (c1){
     	      //***************************************************//
              //***************************************************//
              // Hacer el casting correspondiente para obtener h1  //
              //***************************************************//
              //***************************************************//
             GA1DArrayGenome<int> &h1 =(GA1DArrayGenome<int>&) *c1;
             h1.copy(m,0,0,punto1);
             h1.copy(p,punto1,punto1,punto2);
             n++;
    }

    if (c2){
              //***************************************************//
              //***************************************************//
              // Hacer el casting correspondiente para obtener h2  //
              //***************************************************//
              //***************************************************//
             GA1DArrayGenome<int> &h2 =(GA1DArrayGenome<int> &) *c2;
             h2.copy(p,0,0,punto1);
             h2.copy(m,punto1,punto1,punto2);
             n++;
    }

    return n;
}

bool checkColumna(int col[], int * check, int tam){
     bool repe=false;

     for(int i=0;i<tam;i++) check[i]=0;

     for(int i=0;i<tam;i++)
             check[col[i]-1]++;
     for(int i=0;i<tam;i++) if (check[i]>1) repe=true;

     return repe;
}


int MutacionSudoku(GAGenome& g,float pmut){

     //*******************************************************//
     //*******************************************************//
     // Hacer el casting correspondiente para obtener genome  //
     //*******************************************************//
     //*******************************************************//
     GA1DArrayAlleleGenome<int> &genome =(GA1DArrayAlleleGenome<int> &) g;

    struct plantilla * plantilla1;
    plantilla1 = (struct plantilla *) genome.userData();
    int nmut=0;
    int aux,aux1;
    int fil;
    bool fila;

    int caux[plantilla1->tam];
    int *checkC=new int[plantilla1->tam];

    if (pmut<=0.0) return 0;

    for(int f=0; f<plantilla1->tam; f++)
       for(int c=0; c<plantilla1->tam; c++)
          if (plantilla1->fijo[(f*plantilla1->tam)+c]==0){
           if (GAFlipCoin(pmut) ){
                if (GAFlipCoin(0.5)) fila = true;
                else fila = false;

                if (!fila){

                      for(int j=0;j<plantilla1->tam;j++) caux[j]=genome.gene((j*plantilla1->tam)+c);
                      if (checkColumna(caux,checkC,plantilla1->tam)){
                         int v1 = GARandomInt(0,plantilla1->tam-1);
                         while (checkC[v1]<=1) v1=(v1+1)%plantilla1->tam;
                         v1++;
                         int v2 = GARandomInt(0,plantilla1->tam-1);
                         while (checkC[v2]!=0) v2=(v2+1)%plantilla1->tam;
                         v2++;

                         bool encontrado = false;
                         for(int j=0;j<plantilla1->tam && !encontrado;j++)
                                 if ((plantilla1->fijo[j*(plantilla1->tam)+c]==0)&&(genome.gene(j*(plantilla1->tam)+c)==v1)){
                                    encontrado = true;
                                    genome.gene((j*plantilla1->tam)+c,v2);
                                    fil = j;
                                 }

                         int col=(c+1)%plantilla1->tam;
                         while(genome.gene((fil*plantilla1->tam)+col)!=v2) col=(col+1)%plantilla1->tam;
                         if (plantilla1->fijo[(fil*plantilla1->tam)+col]==0) {
                                nmut++;
                                genome.gene((fil*plantilla1->tam)+col,v1);
                         }
                         else {
                              genome.gene((fil*plantilla1->tam)+c,v1);
                         }

                      }

                }
                else{
                   int v1 = (c + 1) %plantilla1->tam;
                   while ((plantilla1->fijo[(f*plantilla1->tam)+v1]!=0)) v1=(v1+1)%plantilla1->tam;
                   aux = genome.gene((f*plantilla1->tam)+c);
                   genome.gene((f*plantilla1->tam)+c,genome.gene((f*plantilla1->tam)+v1));
                   genome.gene((f*plantilla1->tam)+v1,aux);
                   nmut++;
                }
           }
          }

    return nmut;
}

//Metodo objetivo (fitness).
float Objective(GAGenome& g){
    GA1DArrayAlleleGenome<int> &genome =(GA1DArrayAlleleGenome<int> &) g;
    float fit=0;

// -------------------------------------------- Trato las filas.

    for(int f=0; f<number; f++){
        list<int> fila;
        fila.push_back(0);
        int numfila=f*number;
        for(int i=numfila; i<numfila+number; i++){
            bool repetido=false;
            list<int>::iterator actual;

            for(actual=fila.begin(); actual!=fila.end(); actual++){
                if(*actual==genome.gene(i)){
                    fit++;
                    repetido=true;
                }
            }
            if(!repetido)
                fila.push_back(genome.gene(i));
        }
    }

//-------------------------------------------- Trato las columnas.

    for(int col=0; col<number; col++){
        list<int> columna;
        columna.push_back(0);
        for(int i=col; i<number*number; i+=number){
            bool repetido=false;
            list<int>::iterator actual;

            for(actual=columna.begin(); actual!=columna.end(); actual++){
                if(*actual==genome.gene(i)){
                    fit++;
                    repetido=true;
                }
            }
            if(!repetido)
                columna.push_back(genome.gene(i));
        }
    }

// -------------------------------------------- Trato los bloques, es decir, los cuadros.

    int veces = sqrt(number);
    for(int bloquecolumna=0;bloquecolumna<veces;bloquecolumna++){
        for(int bloquefila=0;bloquefila<veces;bloquefila++){
            int casilla=(bloquecolumna*veces)+(bloquefila*(number*veces));
            int w=0;
            int tempbuff[number];
            int filasCuadro=0;

            do{
            	int aux = casilla;

	            	for(int i=aux; i<aux+veces; i++){
		            	tempbuff[w]=genome.gene(i);
		                w++;
		                casilla++;
	            	}

	            casilla = aux+number;
	            filasCuadro++;
            }while(filasCuadro!=veces);

            list<int> quad;
            quad.push_back(0);

            for(int x=0;x<number;x++){
                bool repetido=false;
                list<int>::iterator actual;

                for(actual=quad.begin(); actual!=quad.end(); actual++){
                    if(*actual==tempbuff[x]){
                        fit++;
                        repetido=true;
                    }
                }
                if(!repetido)
                    quad.push_back(tempbuff[x]);
            }
        }
    }
    return fit;
}

//Metodo de terminacion del algoritmo.
GABoolean Termina(GAGeneticAlgorithm & ga){
	if((ga.statistics().minEver()==0) || (ga.statistics().generation()==ga.nGenerations()))
        return gaTrue;

	return gaFalse;
}

//Los valores estan puestos en el orden que indica el manual de usuario.
int main(int argc, char **argv){

	//Semilla aleatoria.
	GARandomSeed((unsigned int)1);

	//Declaracion del conjunto de alelos (posibles valores de cada gen de nuestro genoma).
	GAAlleleSet<int> alelos;

	//Declaracion del numero de generaciones
	int ngen = 12000;

	//Declaracion e inicializacion de variables para el algoritmo.
	char* archivo=argv[1];
	int popsize = atoi(argv[2]);
	string SelectorStr=string(argv[3]);
	float pcross = atof(argv[4]);
	float pmut = atof(argv[5]);
    cout << "Poblacion: " << popsize << " Probabilidad cruce: " << pcross << " Probabilidad mutacion: " << pmut << " Selector: " << SelectorStr << endl;

	struct plantilla *sudoku = new plantilla;
	leerSudoku(sudoku, archivo);

    //Añadimos los valores al conjunto de alelos..
	for(int i=1;i<number;i++){
        alelos.add(i);
	}

	// Creacion del algoritmo genetico.
	GA1DArrayAlleleGenome<int> genome((number*number),alelos,Objective,sudoku); //Creacion del genoma y una poblacion de ellos.

	genome.initializer(InicioSudoku); // Inicializacion
	genome.crossover(CruceSudoku);  // Cruce
	genome.mutator(MutacionSudoku); // Mutacion
	GASimpleGA ga(genome);
	ga.minimaxi(-1);
	ga.populationSize(popsize); // Tamaño de la poblacion.
	ga.nGenerations(ngen); // Generaciones.
    ga.pMutation(pmut); // Probabilidad mutacion.
	ga.pCrossover(pcross);  // Probabilidad cruce.

    if(SelectorStr=="ruleta"){
        GARouletteWheelSelector selector; // En caso de que el selector sea ruleta.
        ga.selector(selector);
    }

    if(SelectorStr=="torneo"){
        GATournamentSelector selector;     // En caso de que el selector sea torneo.
        ga.selector(selector);
    }

	ga.terminator(Termina);
	ga.evolve(1);

	// Impresion del mejor individuo encontrado, y su valor de fitness.
	cout << "El GA encuentra:\n" << ga.statistics().bestIndividual() << "\n";
	cout << "Mejor valor fitness es " << ga.statistics().minEver() << "\n";
	return 0;
}
